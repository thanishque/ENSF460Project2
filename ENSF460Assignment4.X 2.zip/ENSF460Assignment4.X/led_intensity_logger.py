"""
ENSF 460 – Project 2: LED Intensity Logger and Plotter
Author: Thanishque Harshaa
Date: November 2025

Reads serial data from PIC24F16KA101 at 4800 baud (8-N-1).
Waits for "START" from the board, logs ADC and intensity every ~0.5 s,
writes to CSV, and plots two graphs:
   • Intensity (%) vs Time (s)
   • ADC Reading vs Time (s)
Stops automatically on "END" or after 60 seconds.
"""

import serial
import time
import csv
import matplotlib.pyplot as plt

# ---------------- Configuration ----------------
PORT = "/dev/tty.usbserial-0001"   # Update if your device name differs
BAUD = 4800
CSV_FILENAME = "GroupA_LEDData.csv"
TIMEOUT = 70                       # Safety timeout (seconds)
# ------------------------------------------------

def main():
    print(f"\nWaiting for PIC24 on {PORT} at {BAUD} baud...")
    try:
        ser = serial.Serial(PORT, BAUD, timeout=1)
    except Exception as e:
        print("Error opening serial port:", e)
        return

    data_rows = []
    started = False
    t0 = None

    while True:
        line = ser.readline().decode(errors='ignore').strip()

        if not line:
            if started and (time.time() - t0 > TIMEOUT):
                print("Timeout: No 'END' received.")
                break
            continue

        if "START" in line:
            started = True
            t0 = time.time()
            print("\nLogging started...\n")
            continue

        if "END" in line:
            print("\nLogging complete. Closing port...\n")
            break

        if not started:
            continue

        # Expect: "ADC: 512 | Intensity: 50"
        if "ADC:" in line and "Intensity:" in line:
            try:
                parts = line.replace("ADC:", "").replace("Intensity:", "").split("|")
                adc_val = int(parts[0].strip())
                intensity = int(parts[1].strip())
                t = round(time.time() - t0, 2)
                data_rows.append([t, adc_val, intensity])
                print(f"{t:6.2f}s  ADC={adc_val:4d}  Intensity={intensity:3d}%")
            except Exception:
                pass  # Ignore malformed lines

    ser.close()

    if not data_rows:
        print("No data captured.")
        return

    # ---------- Save to CSV ----------
    with open(CSV_FILENAME, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["time_s", "adc_value", "intensity_percent"])
        writer.writerows(data_rows)

    print(f"Saved {len(data_rows)} samples to {CSV_FILENAME}")

    # ---------- Plot Results ----------
    times = [r[0] for r in data_rows]
    adcs = [r[1] for r in data_rows]
    intensities = [r[2] for r in data_rows]

    plt.figure(figsize=(9, 5))
    plt.subplot(2, 1, 1)
    plt.plot(times, intensities, "-o", linewidth=1)
    plt.ylabel("Intensity (%)")
    plt.grid(True)
    plt.title("LED Intensity vs Time")

    plt.subplot(2, 1, 2)
    plt.plot(times, adcs, "-o", color="orange", linewidth=1)
    plt.xlabel("Time (s)")
    plt.ylabel("ADC Reading")
    plt.grid(True)
    plt.title("ADC Reading vs Time")

    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    main()
