/*
 * File:   PWM.c
 * Author: Thanishque Harshaa
 * Project: ENSF460 Project 2 - LED Intensity Controller
 */

#include "PWM.h"
#include <xc.h>
#include <libpic30.h>

typedef enum { OFF_MODE, ON_MODE, BLINK_MODE, STREAM_MODE } state_t;
extern volatile state_t currentState;
extern volatile uint8_t blinkFlag;

#define LED1 LATAbits.LATA6
#define LED2 LATBbits.LATB9

static volatile uint16_t duty = 0;
static volatile uint8_t activeLED = 1;

void pwmInit(void)
{
    TRISAbits.TRISA6 = 0;
    TRISBbits.TRISB9 = 0;
    LED1 = 0; LED2 = 0;

    T2CONbits.TCS = 0;
    T2CONbits.TCKPS = 0b00;
    PR2 = 500;
    TMR2 = 0;
    IFS0bits.T2IF = 0;
    IEC0bits.T2IE = 1;
    IPC1bits.T2IP = 3;
    T2CONbits.TON = 1;
}

void updateDutyCycle(uint16_t adcVal)
{
    duty = (adcVal * 100) / 1023;
}

void selectActiveLED(uint8_t ledNum)
{
    activeLED = ledNum;
}

void __attribute__((interrupt, no_auto_psv)) _T2Interrupt(void)
{
    static uint16_t counter = 0;
    IFS0bits.T2IF = 0;
    counter++;
    if (counter >= 100) counter = 0;

    uint8_t on = (counter < duty);

    if (currentState == ON_MODE || currentState == BLINK_MODE)
    {
        if (blinkFlag && currentState == BLINK_MODE)
        {
            LED1 = LED2 = 0;
        }
        else
        {
            if (activeLED == 1) { LED1 = on; LED2 = 0; }
            else { LED2 = on; LED1 = 0; }
        }
    }
    else
    {
        LED1 = 0; LED2 = 0;
    }
}
