/*
 * File:   ADC.h
 * Author: Thanishque H.
 * Description: Header for ADC initialization and potentiometer read.
 * Created on: November 25, 2025
 */

#ifndef ADC_H
#define ADC_H

#include <xc.h>
#include <stdint.h>

#define POT_CHANNEL 5   // RB3 = AN5 = Pin 7

// Initialize ADC with selected analog channel
void adc_init(uint8_t an_ch);

// Perform a single ADC conversion and return 10-bit value
uint16_t do_ADC(void);

#endif /* ADC_H */
