/*
 * File:   IOs.c
 * Author: Thanishque H.
 * Description: Handles Change Notification interrupts for pushbuttons.
 * Created on: November 25, 2025
 */
#include <xc.h>
#include "IOs.h"
#include "UART2.h"

volatile uint8_t pb_event = 0;

void initIO(void)
{
    // Configure PB1 = RB7, PB2 = RB4, PB3 = RA4 as inputs
    TRISBbits.TRISB7 = 1;
    TRISBbits.TRISB4 = 1;
    TRISAbits.TRISA4 = 1;

    // Enable internal pull-ups
    CNPU2bits.CN23PUE = 1;  // PB1 (CN23)
    CNPU1bits.CN1PUE = 1;   // PB2 (CN1)
    CNPU1bits.CN0PUE = 1;   // PB3 (CN0)

    // Enable CN interrupts
    CNEN2bits.CN23IE = 1;
    CNEN1bits.CN1IE = 1;
    CNEN1bits.CN0IE = 1;

    // Clear and enable CN interrupt
    IFS1bits.CNIF = 0;
    IEC1bits.CNIE = 1;
    IPC4bits.CNIP = 6;
}

void handleButtonEvent(void)
{
    pb_event = 1;  // signal to main that a button was pressed
}

// ISR for CN interrupts
void __attribute__((__interrupt__, no_auto_psv)) _CNInterrupt(void)
{
    IFS1bits.CNIF = 0;
    handleButtonEvent();
}
