/*
 * File:   ClkChange.h
 * Author: Thanishque Harshaa
 *
 * Created on November 4, 2025, 11:02 AM
 */
#ifndef CLKCHANGE_H
#define CLKCHANGE_H
void newClk(unsigned int clkval);
#endif
