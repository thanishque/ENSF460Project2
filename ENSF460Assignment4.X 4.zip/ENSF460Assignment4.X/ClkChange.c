/*
 * File:   clkChange.c
 * Author: Thanishque H.
 * Modified: November 6, 2025
 */

#include "clkChange.h"
#include <xc.h>

// newClk()
// Used to switch between system clock speeds
// Accepts clkval = 8 (MHz), 500 (kHz), 32 (kHz)
void newClk(unsigned int clkval)
{
    uint8_t oscVal = 0x55; // default (safe fallback)

    // choose oscillator code based on desired freq
    switch (clkval)
    {
        case 8:      // 8 MHz
            oscVal = 0x00;
            break;

        case 500:    // 500 kHz
            oscVal = 0x66;
            break;

        case 32:     // 32 kHz
            oscVal = 0x55;
            break;

        default:
            // invalid input ? default to 32kHz
            oscVal = 0x55;
            break;
    }

    // temporarily raise CPU priority to avoid conflict
    SRbits.IPL = 7;

    // reset divider bits (set to 1:1)
    CLKDIVbits.RCDIV = 0;

    // perform clock switch
    __builtin_write_OSCCONH(oscVal);
    __builtin_write_OSCCONL(0x01);

    // wait for clock switch to complete
    while (OSCCONbits.OSWEN == 1);

    // restore priority
    SRbits.IPL = 0;
}
