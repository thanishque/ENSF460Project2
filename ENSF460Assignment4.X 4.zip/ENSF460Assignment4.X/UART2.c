#include "UART2.h"
#include <libpic30.h>

void InitUART2(void)
{
    U2MODEbits.UARTEN = 0;
    U2BRG = 6; // 4800 baud at 500kHz Fcy
    U2MODEbits.BRGH = 0;
    U2MODEbits.PDSEL = 0;
    U2MODEbits.STSEL = 0;
    U2STAbits.UTXEN = 1;
    U2MODEbits.UARTEN = 1;
}

void Disp2String(const char *s)
{
    while (*s)
    {
        while (U2STAbits.UTXBF);
        U2TXREG = *s++;
    }
}

void Disp2Dec(uint16_t val)
{
    char buf[6];
    sprintf(buf, "%u", val);
    Disp2String(buf);
}
