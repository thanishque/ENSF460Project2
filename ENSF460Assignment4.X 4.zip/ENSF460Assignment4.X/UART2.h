#ifndef UART2_H
#define UART2_H
#include <xc.h>
#include <stdint.h>
void InitUART2(void);
void Disp2String(const char *s);
void Disp2Dec(uint16_t val);
#endif
