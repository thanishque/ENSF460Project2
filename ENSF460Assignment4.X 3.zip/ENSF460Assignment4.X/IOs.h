/*
 * File:   IOs.h
 * Author: Thanishque H.
 * Description: Header for pushbutton setup and interrupt handling.
 * Created on: November 25, 2025
 */

#ifndef IOS_H
#define IOS_H

#include <xc.h>
#include <stdint.h>

// Push button macros
#define PB1 PORTBbits.RB7
#define PB2 PORTBbits.RB4
#define PB3 PORTAbits.RA4

// Initialize all buttons and CN interrupts
void initIO(void);

// Called inside CN ISR to set flags
void handleButtonEvent(void);

// Extern flag accessible from main
extern volatile uint8_t pb_event;

#endif /* IOS_H */
