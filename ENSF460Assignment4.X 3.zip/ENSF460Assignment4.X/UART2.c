#include "xc.h"
#include "UART2.h"

void InitUART2(void)
{
    TRISBbits.TRISB0 = 0;  // TX
    TRISBbits.TRISB1 = 1;  // RX
    LATBbits.LATB0 = 1;

    U2MODEbits.UARTEN = 0;
    U2MODEbits.BRGH = 0;   // standard mode
    U2BRG = 6;              // 4800 baud @ 500 kHz Fcy
    U2MODEbits.PDSEL = 0;   // 8N1
    U2MODEbits.STSEL = 0;

    U2STAbits.UTXEN = 1;    // enable TX
    U2MODEbits.UARTEN = 1;  // enable UART
}

void putch(char c)
{
    while (U2STAbits.UTXBF); // wait for space
    U2TXREG = c;
}

void putsUART2(char *s)
{
    while (*s)
        putch(*s++);
}
