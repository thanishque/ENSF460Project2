/*
 * File:   ADC.c
 * Author: Thanishque H.
 * Description: Potentiometer input reading for LED brightness control.
 * Created on: November 25, 2025
 */

#include "ADC.h"
#define FCY 500000UL
#include <libpic30.h>

void adc_init(uint8_t an_ch)
{
    // Set all pins to digital first
    AD1PCFG = 0xFFFF;

    // Enable selected pin as analog input
    AD1PCFG &= ~(1u << an_ch);

    // Channel selection: positive input = ANx, negative = Vref-
    AD1CHS = 0;
    AD1CHSbits.CH0SA = an_ch;
    AD1CHSbits.CH0NA = 0;

    // ADC control registers
    AD1CON1 = 0;
    AD1CON1bits.FORM = 0;   // integer output
    AD1CON1bits.SSRC = 0;   // manual conversion start
    AD1CON1bits.ASAM = 0;   // manual sampling

    AD1CON2 = 0;            // AVdd/AVss references

    AD1CON3 = 0;
    AD1CON3bits.ADCS = 4;   // Tad = 10 * Tcy
    AD1CON3bits.SAMC = 1;   // sample time

    // Turn ADC ON
    AD1CON1bits.ADON = 1;
}

uint16_t do_ADC(void)
{
    AD1CON1bits.SAMP = 1;   // start sampling
    __delay_us(120);        // short sample delay
    AD1CON1bits.SAMP = 0;   // start conversion

    while (!AD1CON1bits.DONE); // wait for completion

    uint16_t result = ADC1BUF0 & 0x03FF;
    AD1CON1bits.DONE = 0;
    return result;
}
