/*
 * File:   ClkChange.h
 * Author: Thanishque Harshaa
 *
 * Created on November 4, 2025, 11:02 AM
 */
#ifndef CHANGECLK_H
#define CHANGECLK_H

#include <xc.h>

// Function declarations
void newClk(unsigned int clkval);

#endif // CHANGECLK_H