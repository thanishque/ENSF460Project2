/*
 * File:   main.c
 * Author: Thanishque Harshaa
 * Project: ENSF460 Project 2 - LED Intensity Controller
 */

#pragma config BWRP = OFF, BSS = OFF
#pragma config GWRP = OFF, GCP = OFF
#pragma config FNOSC = FRC, IESO = OFF
#pragma config POSCMOD = NONE, OSCIOFNC = ON
#pragma config POSCFREQ = HS, SOSCSEL = SOSCHP, FCKSM = CSECMD
#pragma config WDTPS = PS32768, FWPSA = PR128, WINDIS = OFF, FWDTEN = OFF
#pragma config BOREN = BOR3, PWRTEN = ON, I2C1SEL = PRI, BORV = V18, MCLRE = ON
#pragma config ICS = PGx2
#pragma config DSWDTPS = DSWDTPSF, DSWDTOSC = LPRC, RTCOSC = SOSC
#pragma config DSBOREN = ON, DSWDTEN = ON

#include <xc.h>
#include <p24F16KA101.h>
#include <stdint.h>
#define FCY 500000UL
#include <libpic30.h>

#include "ADC.h"
#include "clkChange.h"
#include "UART2.h"
#include "IOs.h"
#include "PWM.h"

// FSM states
typedef enum { OFF_MODE, ON_MODE, BLINK_MODE, STREAM_MODE } state_t;
state_t currentState = OFF_MODE;

// Global variables
volatile uint8_t blinkFlag = 0;
volatile uint8_t streamFlag = 0;
volatile uint8_t activeLED = 1; // 1 = LED1, 2 = LED2
volatile uint16_t dutyCycle = 0;

// ---------- Blink timer ----------
void setupBlinkTimer(void)
{
    T3CONbits.TCKPS = 0b11; // 1:256 prescale
    PR3 = 1953;             // ~0.5s at 500 kHz
    IFS0bits.T3IF = 0;
    IEC0bits.T3IE = 1;
    IPC2bits.T3IP = 2;
    T3CONbits.TON = 1;
}

// ---------- Interrupts ----------
void __attribute__((interrupt, no_auto_psv)) _T3Interrupt(void)
{
    IFS0bits.T3IF = 0;
    if (currentState == BLINK_MODE)
        blinkFlag ^= 1;
}

// ---------- Main ----------
int main(void)
{
    newClk(500);
    initIO();
    InitUART2();
    adc_init(5);
    pwmInit();
    setupBlinkTimer();

    Disp2String("\r\nSystem Ready\r\n");

    while (1)
    {
        Idle();

        // PB1 click ? toggle ON/OFF
        if (PORTBbits.RB7 == 0)
        {
            __delay_ms(50);
            if (currentState == OFF_MODE)
            {
                currentState = ON_MODE;
                selectActiveLED(1);
                Disp2String("\r\n[ON MODE: LED1 Active]\r\n");
            }
            else
            {
                currentState = OFF_MODE;
                Disp2String("\r\n[OFF MODE]\r\n");
            }
            while (PORTBbits.RB7 == 0);
        }

        // PB1 long press ? swap LEDs
        if (PORTBbits.RB7 == 0)
        {
            uint16_t pressCount = 0;
            while (PORTBbits.RB7 == 0)
            {
                __delay_ms(50);
                pressCount++;
            }
            if (pressCount > 10 && currentState == ON_MODE)
            {
                activeLED = (activeLED == 1) ? 2 : 1;
                selectActiveLED(activeLED);
                Disp2String(activeLED == 1 ? "\r\n[Switched to LED1]\r\n"
                                           : "\r\n[Switched to LED2]\r\n");
            }
        }

        // PB2 click ? toggle blink mode
        if (PORTBbits.RB4 == 0)
        {
            __delay_ms(50);
            if (currentState == ON_MODE)
            {
                currentState = BLINK_MODE;
                blinkFlag = 1;
                Disp2String("\r\n[Blink Mode ON]\r\n");
            }
            else if (currentState == BLINK_MODE)
            {
                currentState = ON_MODE;
                blinkFlag = 0;
                Disp2String("\r\n[Blink Mode OFF]\r\n");
            }
            while (PORTBbits.RB4 == 0);
        }

        // PB3 click ? start UART streaming
        if (PORTAbits.RA4 == 0)
        {
            __delay_ms(50);
            if (streamFlag == 0 && currentState != OFF_MODE)
            {
                streamFlag = 1;
                Disp2String("\r\nSTART\r\n");
                uint32_t elapsed = 0;
                while (elapsed < 60000)
                {
                    uint16_t adc = do_ADC();
                    updateDutyCycle(adc);
                    uint16_t intensity = (adc * 100) / 1023;
                    Disp2String("ADC: ");
                    Disp2Dec(adc);
                    Disp2String(" | Intensity: ");
                    Disp2Dec(intensity);
                    Disp2String("\r\n");
                    __delay_ms(200);
                    elapsed += 200;
                }
                Disp2String("\r\nEND\r\n");
                streamFlag = 0;
            }
            while (PORTAbits.RA4 == 0);
        }
    }
    return 0;
}