/*
 * File:   PWM.h
 * Author: Thanishque Harshaa
 * Description: Software PWM driver for LED intensity control
 */

#ifndef PWM_H
#define PWM_H

#include <xc.h>
#include <stdint.h>

void pwmInit(void);
void updateDutyCycle(uint16_t adcValue);
void selectActiveLED(uint8_t ledNum);

#endif
