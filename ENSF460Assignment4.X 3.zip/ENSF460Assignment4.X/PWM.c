/*
 * File:   PWM.c
 * Author: Thanishque Harshaa
 * Description: Software PWM generation for LED intensity control
 */

#include "PWM.h"
#include <libpic30.h>

#define LED1 LATAbits.LATA6
#define LED2 LATBbits.LATB9

static volatile uint16_t duty = 0;
static volatile uint8_t activeLED = 1; // 1 = LED1, 2 = LED2

// Initialize PWM using Timer2 (~1 kHz)
void pwmInit(void)
{
    // LED pin setup
    TRISAbits.TRISA6 = 0;
    TRISBbits.TRISB9 = 0;
    LED1 = 0;
    LED2 = 0;

    // Timer2 setup for software PWM
    T2CONbits.TCS = 0;       // internal clock
    T2CONbits.TCKPS = 0b01;  // 1:8 prescale
    PR2 = 62500 / 8;         // ~1 kHz PWM period (Fcy = 500 kHz)
    TMR2 = 0;
    IFS0bits.T2IF = 0;
    IEC0bits.T2IE = 1;
    IPC1bits.T2IP = 3;
    T2CONbits.TON = 1;
}

void updateDutyCycle(uint16_t adcValue)
{
    duty = (adcValue * 100) / 1023; // scale 0?100%
}

void selectActiveLED(uint8_t ledNum)
{
    activeLED = ledNum;
}

// Timer2 interrupt for PWM signal generation
void __attribute__((interrupt, no_auto_psv)) _T2Interrupt(void)
{
    static uint16_t counter = 0;
    IFS0bits.T2IF = 0;

    counter++;
    if (counter >= 100)
        counter = 0;

    uint8_t output = (counter < duty);

    if (activeLED == 1)
    {
        LED1 = output;
        LED2 = 0;
    }
    else
    {
        LED2 = output;
        LED1 = 0;
    }
}
