#ifndef UART2_H
#define UART2_H
void InitUART2(void);
void putch(char c);
void putsUART2(char *s);
#endif
